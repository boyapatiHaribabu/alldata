# Make sure that sn.exe has been installed following StrongNameToolResolver.cs 
$SN_EXE = "C:\Program Files (x86)\Microsoft SDKs\Windows\v10.0A\bin\NETFX 4.6 Tools\x64\sn.exe";
if (!(Test-Path $SN_EXE)) {
    $SN_EXE = "C:\Program Files (x86)\Microsoft SDKs\Windows\v8.1A\bin\NETFX 4.5.1 Tools\x64\sn.exe";
    if (!(Test-Path $SN_EXE)) {
        $SN_EXE = "C:\Program Files (x86)\Microsoft SDKs\Windows\v7.0A\Bin\x64\sn.exe";
        if (!(Test-Path $SN_EXE)) {
            Throw "Could not find sn.exe installed on machine."
        }
    }
}

$SN_PFX = Join-Path $PSScriptRoot "src\SilverlightServer\PBI.Security.Cryptography\PBI.Security.Cryptography.pfx"
& $SN_EXE -i $SN_PFX VS_KEY_2A7D0194E40819C4

# & $SN_EXE -d VS_KEY_2A7D0194E40819C4